package com.stx.exercise.p5.hushuangfu;

/**
 * Created by Administrator on 2020/3/9 0009.
 */
public class VehicleDemo {
    public static void main(String[] args) {
        VehicleManager manager = new VehicleManager();
        manager.start();
    }
}
